package com.rajib.amarhisab.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "transactions")
data class Hisab(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val type: String,          // আয়, খরচ, পাওনা, দেনা
    val amount: Long,
    val category: String,
    val note: String,
    val person: String = ""
)

@Dao
interface HisabDao {
    @Query("SELECT * FROM transactions ORDER BY id DESC")
    fun observeAll(): Flow<List<Hisab>>

    @Insert
    suspend fun insert(item: Hisab)

    @Update
    suspend fun update(item: Hisab)

    @Delete
    suspend fun delete(item: Hisab)

    @Query("DELETE FROM transactions")
    suspend fun deleteAll()

    @Query("SELECT * FROM transactions ORDER BY id DESC")
    suspend fun allOnce(): List<Hisab>
}

@Database(entities = [Hisab::class], version = 1, exportSchema = false)
abstract class HisabDatabase : RoomDatabase() {
    abstract fun dao(): HisabDao

    companion object {
        @Volatile private var INSTANCE: HisabDatabase? = null

        fun get(context: Context): HisabDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    HisabDatabase::class.java,
                    "amar_hisab.db"
                ).build().also { INSTANCE = it }
            }
    }
}
