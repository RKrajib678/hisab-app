package com.rajib.amarhisab

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rajib.amarhisab.data.Hisab
import com.rajib.amarhisab.data.HisabDatabase
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

private val Bg = Color(0xFFF7F8FC)
private val Card = Color(0xFFEFF5FF)
private val Primary = Color(0xFF1677FF)

class HisabViewModel(private val dao: com.rajib.amarhisab.data.HisabDao) : ViewModel() {
    val items = dao.observeAll().collectAsState(initial = emptyList())

    fun add(date: String, type: String, amount: Long, category: String, note: String, person: String) {
        viewModelScope.launch {
            dao.insert(Hisab(date = date, type = type, amount = amount, category = category, note = note, person = person))
        }
    }
    fun delete(item: Hisab) = viewModelScope.launch { dao.delete(item) }

    suspend fun all(): List<Hisab> = dao.allOnce()
    suspend fun clear() = dao.deleteAll()
}

class MainActivity : ComponentActivity() {
    private lateinit var vm: HisabViewModel

    private val createBackup = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) exportBackup(uri) }

    private val openBackup = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) importBackup(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm = ViewModelProvider(this, object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return HisabViewModel(HisabDatabase.get(applicationContext).dao()) as T
            }
        })[HisabViewModel::class.java]

        setContent { AmarHisabApp(vm, ::makePdf, ::startBackup, ::startRestore) }
    }

    private fun startBackup() { createBackup.launch("amar_hisab_backup.json") }
    private fun startRestore() { openBackup.launch(arrayOf("application/json", "text/plain")) }

    private fun exportBackup(uri: Uri) {
        lifecycleScope.launch {
            val arr = JSONArray()
            vm.all().forEach {
                arr.put(JSONObject().apply {
                    put("date", it.date); put("type", it.type); put("amount", it.amount)
                    put("category", it.category); put("note", it.note); put("person", it.person)
                })
            }
            contentResolver.openOutputStream(uri)?.use {
                it.write(arr.toString(2).toByteArray(Charsets.UTF_8))
            }
        }
    }

    private fun importBackup(uri: Uri) {
        lifecycleScope.launch {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: return@launch
            val arr = JSONArray(text)
            vm.clear()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                vm.add(
                    o.optString("date"), o.optString("type"), o.optLong("amount"),
                    o.optString("category"), o.optString("note"), o.optString("person")
                )
            }
        }
    }

    private fun makePdf(items: List<Hisab>) {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas = page.canvas
        val p = Paint().apply { textSize = 18f; isAntiAlias = true }
        canvas.drawText("Amar Hisab - হিসাব রিপোর্ট", 40f, 45f, p)
        p.textSize = 11f
        var y = 75f
        items.take(55).forEach {
            val line = "${it.date} | ${it.type} | ${it.amount} | ${it.category} | ${it.note}"
            canvas.drawText(line.take(90), 40f, y, p)
            y += 14f
        }
        doc.finishPage(page)
        val file = java.io.File(cacheDir, "amar_hisab_report.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(this, "${applicationContext.packageName}.fileprovider", file))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(share, "PDF শেয়ার করুন"))
    }
}

@Composable
fun AmarHisabApp(
    vm: HisabViewModel,
    makePdf: (List<Hisab>) -> Unit,
    backup: () -> Unit,
    restore: () -> Unit
) {
    val items by vm.items
    var tab by rememberSaveable { mutableIntStateOf(0) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Primary,
            background = Bg,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("হোম") })
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.AddCircle, null) }, label = { Text("যোগ") })
                    NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.List, null) }, label = { Text("হিসাব") })
                    NavigationBarItem(tab == 3, { tab = 3 }, icon = { Icon(Icons.Default.Assessment, null) }, label = { Text("রিপোর্ট") })
                }
            }
        ) { pad ->
            when (tab) {
                0 -> HomeScreen(items, Modifier.padding(pad))
                1 -> AddScreen(vm, Modifier.padding(pad))
                2 -> HistoryScreen(items, vm, Modifier.padding(pad))
                3 -> ReportScreen(items, makePdf, backup, restore, Modifier.padding(pad))
            }
        }
    }
}

@Composable
fun HomeScreen(items: List<Hisab>, modifier: Modifier = Modifier) {
    val income = items.filter { it.type == "আয়" }.sumOf { it.amount }
    val expense = items.filter { it.type == "খরচ" }.sumOf { it.amount }
    val due = items.filter { it.type == "পাওনা" }.sumOf { it.amount }
    val debt = items.filter { it.type == "দেনা" }.sumOf { it.amount }

    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("📊  আমার হিসাব", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("সব হিসাব ফোনেই থাকবে — অফলাইন", color = Color.Gray)
        }
        item { SummaryCard("মোট আয়", income, Color(0xFFE8F7EA)) }
        item { SummaryCard("মোট খরচ", expense, Color(0xFFFFEEEE)) }
        item { SummaryCard("পাওনা", due, Card) }
        item { SummaryCard("দেনা", debt, Card) }
        item {
            SummaryCard("বর্তমান হিসাব", income - expense + due - debt, Color(0xFFEAF1FF))
        }
    }
}

@Composable
fun SummaryCard(title: String, amount: Long, color: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = color), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(20.dp)) {
            Text(title, fontSize = 18.sp)
            Text("৳ $amount", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AddScreen(vm: HisabViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var type by rememberSaveable { mutableStateOf("আয়") }
    var amount by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var person by rememberSaveable { mutableStateOf("") }
    var date by rememberSaveable { mutableStateOf(today()) }

    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("নতুন হিসাব", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        TypeRow(type) { type = it }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = {
            val cal = Calendar.getInstance()
            DatePickerDialog(context, { _, y, m, d ->
                date = "%02d/%02d/%04d".format(d, m + 1, y)
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }, modifier = Modifier.fillMaxWidth()) { Text("তারিখ: $date") }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("টাকার পরিমাণ") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(category, { category = it }, label = { Text("কিসের হিসাব?") }, placeholder = { Text("যেমন: ডিজেল / লাইন খরচ / ভাড়া") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(person, { person = it }, label = { Text("কার সাথে? (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(note, { note = it }, label = { Text("বিস্তারিত") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = {
                val n = amount.toLongOrNull() ?: 0
                if (n > 0) {
                    vm.add(date, type, n, category, note, person)
                    amount = ""; category = ""; note = ""; person = ""
                }
            },
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text("হিসাব যোগ করুন", fontSize = 18.sp) }
    }
}

@Composable
fun TypeRow(type: String, onType: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("আয়", "খরচ", "পাওনা", "দেনা").forEach {
            FilterChip(selected = type == it, onClick = { onType(it) }, label = { Text(it) })
        }
    }
}

@Composable
fun HistoryScreen(items: List<Hisab>, vm: HisabViewModel, modifier: Modifier = Modifier) {
    var search by rememberSaveable { mutableStateOf("") }
    val filtered = items.filter {
        search.isBlank() || listOf(it.date, it.type, it.category, it.note, it.person).any { s -> s.contains(search, true) }
    }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("📋 হিসাবের তালিকা", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(search, { search = it }, label = { Text("খুঁজুন") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { item ->
                Card {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${item.type} • ${item.category}", fontWeight = FontWeight.Bold)
                            Text("${item.date}  ${item.note}")
                            if (item.person.isNotBlank()) Text("ব্যক্তি: ${item.person}")
                        }
                        Text("৳${item.amount}", fontWeight = FontWeight.Bold)
                        IconButton({ vm.delete(item) }) { Icon(Icons.Default.Delete, null) }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportScreen(
    items: List<Hisab>,
    makePdf: (List<Hisab>) -> Unit,
    backup: () -> Unit,
    restore: () -> Unit,
    modifier: Modifier = Modifier
) {
    val income = items.filter { it.type == "আয়" }.sumOf { it.amount }
    val expense = items.filter { it.type == "খরচ" }.sumOf { it.amount }
    val due = items.filter { it.type == "পাওনা" }.sumOf { it.amount }
    val debt = items.filter { it.type == "দেনা" }.sumOf { it.amount }

    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("📈 রিপোর্ট ও ব্যাকআপ", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Text("মোট আয়: ৳$income")
        Text("মোট খরচ: ৳$expense")
        Text("মোট পাওনা: ৳$due")
        Text("মোট দেনা: ৳$debt")
        Text("নিট: ৳${income - expense + due - debt}", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Button(onClick = { makePdf(items) }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text("PDF রিপোর্ট তৈরি করুন")
        }
        OutlinedButton(onClick = backup, modifier = Modifier.fillMaxWidth()) { Text("💾 হিসাব Backup করুন") }
        OutlinedButton(onClick = restore, modifier = Modifier.fillMaxWidth()) { Text("♻️ Backup Restore করুন") }
        Spacer(Modifier.height(12.dp))
        Text("নোট: অ্যাপটি কোনো Google/Cloud সার্ভারে স্বয়ংক্রিয়ভাবে আপনার হিসাব পাঠায় না।", color = Color.Gray)
    }
}

private fun today(): String = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
